package partida.ataques;

public class JineteAsediadoException extends Exception {
    public JineteAsediadoException() {
        super("El jinete Asediado no ataca a distancia");
    }
}
