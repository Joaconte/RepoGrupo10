package partida.ataques;

public class JineteNoAsediadoException extends Exception {
        public JineteNoAsediadoException() {
            super("El jinete no Asediado ataca a distancia");
        }
}
