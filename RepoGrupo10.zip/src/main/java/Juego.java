import partida.Partida;
public class Juego {

    private Partida partida;

}
