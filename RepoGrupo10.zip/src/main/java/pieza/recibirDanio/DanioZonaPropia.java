package pieza.recibirDanio;

public class DanioZonaPropia implements IModoRecibirDanio {
    @Override
    public double danio(double danioBase) {
        return danioBase;
    }
}
