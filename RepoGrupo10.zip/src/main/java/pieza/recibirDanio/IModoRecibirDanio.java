package pieza.recibirDanio;

public interface IModoRecibirDanio {
    public double danio(double danioBase);
}
