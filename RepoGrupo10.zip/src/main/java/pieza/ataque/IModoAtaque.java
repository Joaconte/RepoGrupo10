package pieza.ataque;

import pieza.Pieza;

public interface IModoAtaque {
    public void atacar(PiezaAtacante miUnidad, Pieza victima);
}
