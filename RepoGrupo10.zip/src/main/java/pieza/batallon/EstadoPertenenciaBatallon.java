package pieza.batallon;

public interface EstadoPertenenciaBatallon {

}
