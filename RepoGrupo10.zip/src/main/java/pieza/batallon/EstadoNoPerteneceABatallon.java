package pieza.batallon;

public class EstadoNoPerteneceABatallon implements EstadoPertenenciaBatallon {

}
