package pieza.batallon;

public class EstadoPerteneceABatallon implements EstadoPertenenciaBatallon {

}
