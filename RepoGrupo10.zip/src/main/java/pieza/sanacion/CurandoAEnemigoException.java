package pieza.sanacion;

public class CurandoAEnemigoException extends Exception{

    public CurandoAEnemigoException (){
        super("No se puede curar a Enemigos");
    }
}
