package pieza.sanacion;

public interface IModoSanacion {
    public int restaurarPuntosDeVida(int vida) throws UnidadNoSePuedeCurar;
}
